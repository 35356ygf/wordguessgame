package com.example.word_guess_game;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WordGuessGameApplication {

	public static void main(String[] args) {
		SpringApplication.run(WordGuessGameApplication.class, args);
	}

}
