package com.example.word_guess_game;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WordGuessGameApplicationTests {

	@Test
	void contextLoads() {
	}

}
